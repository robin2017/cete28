package game.snakegame.util;

public class Global {
	public static final int CELL_WIDTH = 20;
	public static final  int CELL_HEIGHT = 20;
	public static final int CELL_SIZE = 35;
}
