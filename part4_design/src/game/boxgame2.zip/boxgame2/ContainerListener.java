package game.boxgame2;

/**
 * Created by robin on 2017/8/16.
 */
public interface ContainerListener {
    public void boxesDeclinedFromContainer();
}
