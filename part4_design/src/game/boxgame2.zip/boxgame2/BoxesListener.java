package game.boxgame2;

/**
 * Created by robin on 2017/8/16.
 */
public interface BoxesListener {
    public void boxesDeclinedFromBoxes();
}
