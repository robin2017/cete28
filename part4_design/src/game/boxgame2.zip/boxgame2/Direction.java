package game.boxgame2;

/**
 * Created by robin on 2017/8/15.
 */
public enum Direction {
    UP,DOWN,LEFT,RIGHT;
}
