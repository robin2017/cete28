package game.boxgame2;

public class Global {
	public static final int CELL_WIDTH = 20;
	public static final  int CELL_HEIGHT = 20;
	public static final int CELL_SIZE = 15;
}
