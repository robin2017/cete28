package day06.ServerTest.test;

/**
 * Created by robin on 2017/8/8.
 */
public class IdPassException extends Exception {
   public IdPassException(String msg){
       super(msg);
   }
}
