package day06.homework.rpcdemo2;

public class IdPassException extends Exception {
	public IdPassException(String msg){
		super(msg);
	}
}
