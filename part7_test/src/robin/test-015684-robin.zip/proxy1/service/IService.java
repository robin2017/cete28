package robin.proxy1.service;

/**
 * Created by robin on 2017/8/24.
 */
public interface IService{
    public void saveObject();
}